export enum NetworkID {
                  Mainnet = 56,
                  Testnet = 4,
                }