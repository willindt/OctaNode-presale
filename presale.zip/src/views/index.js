export { default as Stake } from "./Stake/Stake";
export { default as Presale } from "./Presale/Presale";
export { default as Claim } from "./Claim/Claim";
